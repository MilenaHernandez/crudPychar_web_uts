const api_url = "http://127.0.0.1:8000/api/beca/";

async function getapi(url) {
    const response = await fetch(url);
    var data = await response.json();
    show(data);
}

// Calling that async function
getapi(api_url);

// Function to define innerHTML for HTML table
function show(data) {

    let tab =
        `<tr>
          <th>Actualizar</th>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Fecha</th>
          <th>Sexo</th>
          <th>Ciudadania</th>
          <th>Pais</th>
          <th>Detalles</th>
          <th>Eliminar</th>
         </tr>`;
    // Loop to access all rows

    for (let i in data) {
        tab += `<tr> 
            <td>
                <button style="cursor: pointer" onClick="formUpdate(${data[i].beca_id});">
                    <img src="images_1/actualizar.png" alt="">
                </button>
            </td>
            <td>${data[i].beca_name}</td>
            <td>${data[i].beca_lname}</td>
            <td>${data[i].beca_date}</td> 
            <td>${data[i].beca_gender}</td>
            <td>${data[i].beca_citizenship}</td>
            <td>${data[i].beca_country}</td>
            <td>${data[i].beca_message}</td>
            <td>
                <button style="cursor: pointer" 
                    onclick="if(confirm('Desea Eliminar el Registro?'+${data[i].beca_id})){eliminar(${data[i].beca_id})}else{ alert('Operación Cancelada');}">
                    <img src="images_1/eliminar.png">
                </button>
            </td>
            </tr>`;

    }
    document.getElementById("solicitantes").innerHTML = tab;

}
function insertar() {
    document.getElementById('formulario').style.display = 'block';
    document.getElementById('contenido').style.display = 'none';
    document.getElementById('tabla').style.display = 'none';
    $("#actualizar").hide();
}

function formUpdate(id) {
    fetch(api_url+id+'/')
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            showUpdate(data);
        })
        .catch(function(err) {
            console.error(err);
        });
}

function showUpdate(data){
    insertar();
    $("#id").val(data.beca_id);
    $("#name").val(data.beca_name);
    $("#lname").val(data.beca_lname);
    $("#date").val(data.beca_date);
    $(":radio[value=" + data.beca_gender + "]").prop('checked', true);
    $("#citizenship").val(data.beca_citizenship);
    $("#country option[value='"+data.beca_country+"']").prop("selected",true);
    $("#message").val(data.beca_message);

    document.getElementById('enviar').style.display = 'none';
    $("#actualizar").show();
}

function eliminar(id) {
    fetch(api_url+id+'/', {
        method: 'DELETE'
    })
    .then(function(response) {
        location.reload();
    });
}

function crear_actualizar(num){
    let tipo = 'POST', url = api_url;
    if (num === 1){
        tipo = 'PUT'
        url+=$('#id').val()+'/'
    }

    var radioGender = document.getElementsByName('beca_gender');
    for(let i=0; i<radioGender.length; i++){
        if(radioGender[i].checked){
            var gender = radioGender[i].value;
        }
    }

    fetch(url, {
        method: tipo,
        body: JSON.stringify({
            beca_name: $('#name').val(),
            beca_lname: $('#lname').val(),
            beca_date: $('#date').val(),
            beca_gender: gender,
            beca_citizenship: $('#citizenship').val(),
            beca_country: $('#country').val(),
            beca_message: $('#message').val()
        }),
        headers: {
            "Content-type": "application/json"
        },})
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            location.reload();
        });
}
