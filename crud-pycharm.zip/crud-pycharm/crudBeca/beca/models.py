from django.db import models


class BecaModel(models.Model):
    beca_id = models.AutoField(primary_key=True)
    beca_name = models.TextField(max_length=50)
    beca_lname = models.TextField(max_length=50)
    beca_date = models.DateField()
    beca_gender = models.TextField(max_length=10)
    beca_citizenship = models.TextField(max_length=50)
    beca_country = models.TextField(max_length=50)
    beca_message = models.TextField()
