from rest_framework import serializers

from beca.models import BecaModel


class BecaSerializer(serializers.Serializer):
    beca_id = serializers.IntegerField(required=False)
    beca_name = serializers.CharField(required=True)
    beca_lname = serializers.CharField(required=True)
    beca_date = serializers.DateField(required=False)
    beca_gender = serializers.CharField(required=False)
    beca_citizenship = serializers.CharField(required=False)
    beca_country = serializers.CharField(required=False)
    beca_message = serializers.CharField(required=False)

    class Meta:
        fields = '__all__'

    def create(self, validated_data):
        return BecaModel.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.beca_id = validated_data.get('beca_id', instance.beca_id)
        instance.beca_name = validated_data.get('beca_name', instance.beca_name)
        instance.beca_lname = validated_data.get('beca_lname', instance.beca_lname)
        instance.beca_date = validated_data.get('beca_date', instance.beca_date)
        instance.beca_gender = validated_data.get('beca_gender', instance.beca_gender)
        instance.beca_citizenship = validated_data.get('beca_citizenship', instance.beca_citizenship)
        instance.beca_country = validated_data.get('beca_country', instance.beca_country)
        instance.beca_message = validated_data.get('beca_message', instance.beca_message)
        instance.save()
        return instance
