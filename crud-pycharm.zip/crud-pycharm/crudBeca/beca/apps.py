from django.apps import AppConfig


class BecaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'beca'
